public class Pato {
    public static void main(String[] args) {
        Pato pato = new Pato();
        pato.volar();
        pato.nadar();
    }

    public void volar() {
        System.out.println("El pato está volando.");
    }

    public void nadar() {
        System.out.println("El pato está nadando.");
    }
}