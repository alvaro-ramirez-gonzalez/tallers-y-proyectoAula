// Clase principal para probar las clases Persona y Empleado
public class Principal {
    public static void main(String[] args) {
        // Crear un objeto Persona
        Persona persona = new Persona("Carlos", 30);
        System.out.println("Detalles de la Persona:");
        persona.mostrarDetalles();
        
    }
}
