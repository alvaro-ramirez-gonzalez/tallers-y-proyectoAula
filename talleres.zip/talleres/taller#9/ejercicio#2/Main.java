// Ejemplo de uso
public class Main {
    public static void main(String[] args) {
        // Se puede crear un Pez y llamar al método mostrarEspecie
        Pez pez = new Pez("Salmón", "Agua dulce");
        pez.mostrarEspecie();
    }
}
