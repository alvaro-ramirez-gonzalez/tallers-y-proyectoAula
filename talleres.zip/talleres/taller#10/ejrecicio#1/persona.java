// Clase base Persona
class Persona {
    // Método presentarse en la clase Persona
    public void presentarse() {
        System.out.println("Hola, soy una persona.");
    }
}

